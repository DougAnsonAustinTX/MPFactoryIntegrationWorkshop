#!/bin/bash

PYTHON="python3"
if [ -x /usr/bin/python3.6 ]; then
   PYTHON="python3.6"
fi
if [ -x /usr/bin/python3.7 ]; then
   PYTHON="python3.7"
fi
if [ -x /usr/bin/python3.8 ]; then
   PYTHON="python3.8"
fi
if [ -x /usr/bin/python3.9 ]; then
   PYTHON="python3.9"
fi
echo "Python used: "${PYTHON}

INSTALL_DIR="$1"
LOGFILE="/tmp/OPCUAMotorRPMSimulator.log"
if [ -f ${LOGFILE} ]; then
    mv ${LOGFILE} ${LOGFILE}-$$
fi

echo "Starting OPCUAMotorRPMSimulator..."
echo ${PYTHON} -u ${INSTALL_DIR}/OPCUAMotorRPMSimulator.py --csvOff 1> ${LOGFILE} 2>&1
${PYTHON} -u ${INSTALL_DIR}/OPCUAMotorRPMSimulator.py --csvOff 1>> ${LOGFILE} 2>&1
