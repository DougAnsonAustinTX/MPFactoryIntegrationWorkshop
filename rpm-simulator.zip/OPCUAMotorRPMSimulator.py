# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

import sys
import logging
import time
import opcua
import random
import json
import os
import traceback
from opcua import Server

# instantiate logger which will log any exceptions to Cloudwatch or Greengrass
# local logs
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)

class OPCUAMotorRPMSimulator(object):
    def __init__(self,boundary_initial, motors_initial):
        '''
        Constructor
        '''
        # configure the server
        self.server = Server()
        self.motors = motors_initial
        self.boundary = boundary_initial
        self.uri = "opc.tcp://0.0.0.0:4840/"
        self.server.set_endpoint(self.uri)
        # setup our own namespace, not really necessary but should as spec
        self.idx = self.server.register_namespace(self.uri)
        # get Objects node, this is where we should put our nodes
        self.objects = self.server.get_objects_node()
        
        # set up nodes
        self.rootObject = self.objects.add_object(self.idx, "Root")
        self.factory1Object = self.rootObject.add_object(self.idx, "Factory1")
        self.floor0Object = self.factory1Object.add_object(self.idx, "Floor0")
        self.floor0MotorObjects = []

        # setup the motors
        for motor in self.motors:
            logger.info("Adding Motor: " + motor['name'] + "...")
            motor_i = self.floor0Object.add_variable(self.idx, motor['name'], val=motor['current'], datatype=opcua.ua.ObjectIds.Integer)
            motor_i.set_writable()
            self.floor0MotorObjects.append(motor_i)

    def startSimulator(self):
        logger.info("Starting Motor RPM Simulator...")
        self.server.start()
        logger.info("Motor RPM Simulator running...")

    def stopServer(self):
        logger.info("Stopping Motor RPM Simulator...")
        self.server.stop()
        logger.info("Motor RPM Simulator has been stopped.")

    def updateMotors(self):
        index = 0
        for motor in self.motors:
            self.updateMotorRPM(index,motor)
            index = index + 1

    def simulateRPMChange(self, motor):
        motor['current'] = random.randint(motor['low'] - self.boundary, motor['high'] + self.boundary)

    def updateMotorRPM(self, index, motor):
        self.simulateRPMChange(motor)
        logger.debug("Motor RPM Simulator: Updating Motor: " + motor['name'] + ": New RPM Reading: " + str(motor['current']))
        self.floor0MotorObjects[index].set_value(motor['current'])

if __name__ == "__main__":
    try: 
        # Get Configuration parameters
        parameters = json.loads(os.getenv("CONFIG_PARAMETERS"))
        period = parameters['update_period']
        motors = json.loads(parameters['motors'])
        boundary = parameters['boundary']

        # Initialize and start the simulator
        simulator = OPCUAMotorRPMSimulator(boundary, motors)
        simulator.startSimulator()

        # Main loop: update motors RPM...
        while True:
            simulator.updateMotors()
            time.sleep(period)
    except Exception as e:
        logging.error(e)
        logging.error("Motor RPM Simulator: Traceback within main():")
        logging.error(traceback.format_exc())
    logging.info("Motor RPM Simulator: exited.")