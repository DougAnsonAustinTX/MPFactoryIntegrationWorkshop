#!/bin/sh

# Kill the primary component...
PID="`ps -ef | grep OPCUAMotorRPMSimulator.py | grep -v grep | awk '{print $2}'`"
if [ ! -z "${PID}" ]; then
   echo "Killing OPCUAMotorRPMSimulator.py PID:" ${PID} "..."
   kill -9 ${PID}
else
   echo "INFO: OPCUAMotorRPMSimulator.py does not appear to be running"
fi

# Exit
exit 0
