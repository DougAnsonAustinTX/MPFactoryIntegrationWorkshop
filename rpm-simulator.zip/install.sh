#!/bin/bash

PYTHON="python3"
if [ -x /usr/bin/python3.6 ]; then
   PYTHON="python3.6"
fi
if [ -x /usr/bin/python3.7 ]; then
   PYTHON="python3.7"
fi
if [ -x /usr/bin/python3.8 ]; then
   PYTHON="python3.8"
fi
if [ -x /usr/bin/python3.9 ]; then
   PYTHON="python3.9"
fi
echo "Python used: "${PYTHON}
${PYTHON} -m pip install -r ./requirements.txt
